package com.example.travelogue

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Button

class HomePage : AppCompatActivity() {

    private lateinit var addEntryButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)

        // A sample of journal entries
        val journals = arrayListOf(
            JournalEntry("The Pyramids", "01/08/2024", "10:00 AM", R.drawable.pyramids, "Visited the Pyramids, One of the wonders of the world, it was genuinely the best feeling ever!", "Egypt"),
            JournalEntry("Eiffel Tower", "03/08/2024", "02:00 PM", R.drawable.paris, "Saw the Eiffel Tower, I thought it would be more amusing in real life but it was not really", "France")
        )

        // Setup RecyclerView
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = JournalAdapter(this, journals)

        // Initialize the "Add New Journal Entry" button
        addEntryButton = findViewById(R.id.addEntryButton)
        addEntryButton.setOnClickListener {
            val intent = Intent(this, AddEntryActivity::class.java)
            startActivity(intent)
        }
    }

}
