package com.example.travelogue

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.example.travelogue.R
import java.util.Calendar
import java.util.Locale

class AddEntryActivity : ComponentActivity() {
    private lateinit var imageView: ImageView
    private lateinit var titleEditText: EditText
    private lateinit var notesEditText: EditText

    private val takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap: Bitmap? ->
        bitmap?.let {
            imageView.setImageBitmap(it)
        }
    }

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            imageView.setImageURI(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_entry)

        imageView = findViewById(R.id.imageView)
        titleEditText = findViewById(R.id.titleEditText)
        notesEditText = findViewById(R.id.notesEditText)
        val dateEditText: EditText = findViewById(R.id.dateEditText)
        val timeEditText: EditText = findViewById(R.id.timeEditText)
        val selectImageButton: Button = findViewById(R.id.selectImageButton)
        val saveButton: Button = findViewById(R.id.saveButton)
        val countrySpinner: Spinner = findViewById(R.id.selectLocationButton)

        // Set up DatePickerDialog
        dateEditText.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = DatePickerDialog(
                this,
                { _, selectedYear, selectedMonth, selectedDay ->
                    val formattedDate = "${selectedDay}/${selectedMonth + 1}/$selectedYear"
                    dateEditText.setText(formattedDate)
                },
                year,
                month,
                day
            )
            datePickerDialog.show()
        }

        // Set up TimePickerDialog
        timeEditText.setOnClickListener {
            val calendar = Calendar.getInstance()
            val hour = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)

            val timePickerDialog = TimePickerDialog(
                this,
                { _, selectedHour, selectedMinute ->
                    val formattedTime = String.format("%02d:%02d", selectedHour, selectedMinute)
                    timeEditText.setText(formattedTime)
                },
                hour,
                minute,
                true
            )
            timePickerDialog.show()
        }

        // Set up image selection
        selectImageButton.setOnClickListener {
            val options = arrayOf("Take Photo", "Choose from Gallery")
            val builder = android.app.AlertDialog.Builder(this)
            builder.setTitle("Select Option")
            builder.setItems(options) { _, which ->
                when (which) {
                    0 -> takePictureLauncher.launch(null)
                    1 -> pickImageLauncher.launch("image/*")
                }
            }
            builder.show()
        }

        // Set up country spinner
        val countries = mutableListOf("Choose Location")
        countries.addAll(getAllCountries())

        val countryAdapter = ArrayAdapter(
            this,
            R.layout.spinner_item, // use custom layout for items
            countries
        )
        countryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        countrySpinner.adapter = countryAdapter

        // Set up save button
        saveButton.setOnClickListener {
            val title = titleEditText.text.toString().trim()
            val notes = notesEditText.text.toString().trim()
            val date = dateEditText.text.toString().trim()
            val time = timeEditText.text.toString().trim()
            val selectedCountry = countrySpinner.selectedItem.toString()

            if (title.isEmpty()) {
                titleEditText.error = "Please enter a title"
                return@setOnClickListener
            }


            if (date.isEmpty()) {
                dateEditText.error = "Please select a date"
                return@setOnClickListener
            }

            if (time.isEmpty()) {
                timeEditText.error = "Please select a time"
                return@setOnClickListener
            }

            if (selectedCountry == "Choose Location") {
                Toast.makeText(this, "Please choose a location", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (notes.isEmpty()) {
                notesEditText.error = "Please enter description"
                return@setOnClickListener
            }

            // Save the journal entry
            Toast.makeText(this, "Journal has been saved", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getAllCountries(): List<String> {
        val locales = Locale.getISOCountries()
        val countries = mutableListOf<String>()

        for (countryCode in locales) {
            val locale = Locale("", countryCode)
            val countryName = locale.displayCountry
            countries.add(countryName)
        }
        return countries.sorted()
    }
}
