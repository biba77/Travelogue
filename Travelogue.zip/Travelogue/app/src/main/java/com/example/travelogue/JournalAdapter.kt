package com.example.travelogue

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class JournalAdapter(private val context: Context, private val journalList: List<JournalEntry>) :
    RecyclerView.Adapter<JournalAdapter.JournalViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JournalViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.journal_item, parent, false)
        return JournalViewHolder(view)
    }

    override fun onBindViewHolder(holder: JournalViewHolder, position: Int) {
        val journal = journalList[position]
        holder.titleTextView.text = journal.title
        holder.dateTextView.text = journal.date
        holder.imageView.setImageResource(journal.imageUri)

        holder.itemView.setOnClickListener {
            val intent = Intent(context, EntryDetailActivity::class.java).apply {
                putExtra("title", journal.title)
                putExtra("date", journal.date)
                putExtra("time", journal.time)
                putExtra("location", journal.location)
                putExtra("description", journal.notes)
                putExtra("imageResId", journal.imageUri)
            }
            context.startActivity(intent)
        }
    }

    override fun getItemCount() = journalList.size

    class JournalViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.journalTitleTextView)
        val dateTextView: TextView = itemView.findViewById(R.id.journalDateTextView)
        val imageView: ImageView = itemView.findViewById(R.id.journalImageView)
    }
}
